import type { Config } from "tailwindcss";
const { nextui } = require("@nextui-org/react");
const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./common-modals/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic":
          "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
      },
      fontFamily: {
        rbBold: ["var(--font-rb-bold)"],
        rbLight: ["var(--font-rb-light)"],
        rbRegular: ["var(--font-rb-reg)"],
        bahijRegular: ["var(--font-bah-reg)"],
        bahijSemibold: ["var(--font-bah-semibold)"],
      },
    },
  },
  plugins: [nextui()],
};
export default config;
